from Live import load_game, welcome
welcome("Aviel")
load_game()
